﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using AfricanIDSPIMS.Interfaces;
using Xamarin.Essentials;
using AfricanIDSPIMS.Models;

namespace AfricanIDSPIMS.Services
{
    public class UserDataStore : IDataStore<User>
    {
        HttpClient client;
        IEnumerable<User> items;

        public UserDataStore()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri($"https://pims-appservice.azurewebsites.net/api/Users");

            items = new List<User>();
        }

        bool IsConnected => Connectivity.NetworkAccess == NetworkAccess.Internet;
        public async Task<IEnumerable<User>> GetItemsAsync(bool forceRefresh = false)
        {
            if (IsConnected)
            {
                var json = await client.GetStringAsync($"{client.BaseAddress}");
                items = await Task.Run(() => JsonConvert.DeserializeObject<IEnumerable<User>>(json));
            }

            return items;
        }

        public async Task<User> GetItemAsync(string id)
        {
            if (id != null && IsConnected)
            {
                var json = await client.GetStringAsync($"{client.BaseAddress}/{id}");
                return await Task.Run(() => JsonConvert.DeserializeObject<User>(json));
            }

            return null;
        }

        public async Task<bool> AddItemAsync(User item)
        {
            if (item == null || !IsConnected)
                return false;

            var serializedItem = JsonConvert.SerializeObject(item);

            var response = await client.PostAsync($"{client.BaseAddress}", new StringContent(serializedItem, Encoding.UTF8, "application/json"));

            return response.IsSuccessStatusCode;
        }

        public async Task<bool> UpdateItemAsync(User item)
        {
            if (item == null || item.Id == 0 || !IsConnected)
                return false;

            var serializedItem = JsonConvert.SerializeObject(item);
            var buffer = Encoding.UTF8.GetBytes(serializedItem);
            var byteContent = new ByteArrayContent(buffer);

            var response = await client.PutAsync(new Uri($"{client.BaseAddress}/{item.Id}"), byteContent);

            return response.IsSuccessStatusCode;
        }

        public async Task<bool> DeleteItemAsync(string id)
        {
            if (string.IsNullOrEmpty(id) && !IsConnected)
                return false;

            var response = await client.DeleteAsync($"{client.BaseAddress}/{id}");

            return response.IsSuccessStatusCode;
        }
    }
}

