﻿using System;
using System.Windows.Input;
using MvvmHelpers;
using Xamarin.Essentials;
using AfricanIDSPIMS.Services;
using Xamarin.Forms;

namespace AfricanIDSPIMS.ViewModels
{
	public class BankDetailsViewModel : BaseViewModel
	{
        UserDataStore _user;
		public BankDetailsViewModel()
		{
            _user = new UserDataStore();
            FetchUser();
			SaveCommand = new Command(SaveAction);
		}

        private void FetchUser()
        {
            if (App.SelectedUser != null)
            {
                if (App.SelectedUser.BankDetails != null)
                {
                    BankName = App.SelectedUser.BankDetails.BankName;
                    AccountHolder = App.SelectedUser.BankDetails.AccountHolder;
                    AccountNumber = App.SelectedUser.BankDetails.AccountNumber;
                    AccountType = App.SelectedUser.BankDetails.AccountType;
                    BranchCode = App.SelectedUser.BankDetails.BranchCode;
                }
            }
        }

        private async void SaveAction()
        {
            if (App.SelectedUser.BankDetails == null)
            {
                App.SelectedUser.BankDetails = new Models.BankDetails();
                App.SelectedUser.BankDetails.BankName = BankName;
                App.SelectedUser.BankDetails.AccountHolder = AccountHolder;
                App.SelectedUser.BankDetails.AccountNumber = AccountNumber;
                App.SelectedUser.BankDetails.AccountType = AccountType;
                App.SelectedUser.BankDetails.BranchCode = BranchCode;

                var result = await _user.AddItemAsync(App.SelectedUser);
                if (result)
                {
                    await App.Current.MainPage.DisplayAlert("Success!", "You record has been updated!", "Ok");
                }
            }
        }

        public ICommand SaveCommand { get; set; }
        private string bankName;
        private string accountHolder;
        private string accountNumber;
        private string accountType;
        private string branchCode;
        private string agreement;

        public string BankName
        { get => bankName; set => SetProperty(ref bankName,value); }

        public string AccountHolder
        { get => accountHolder; set => SetProperty(ref accountHolder,value); }

        public string AccountNumber
        { get => accountNumber; set => SetProperty(ref accountNumber,value); }

        public string AccountType
        { get => accountType; set => SetProperty(ref accountType,value); }

        public string BranchCode
        { get => branchCode; set => SetProperty(ref branchCode,value); }

        public string Agreement
        { get => agreement; set => SetProperty(ref agreement, value); }




    }
}

