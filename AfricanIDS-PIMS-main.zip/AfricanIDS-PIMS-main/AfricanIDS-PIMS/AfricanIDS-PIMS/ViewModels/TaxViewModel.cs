﻿using System;
using System.Windows.Input;
using MvvmHelpers;
using Xamarin.Forms;

namespace AfricanIDSPIMS.ViewModels
{
	public class TaxViewModel : BaseViewModel
	{
		public TaxViewModel()
		{
            SaveCommand = new Command(SaveAction);
        }

        private void SaveAction()
        {
            throw new NotImplementedException();
        }

        ICommand SaveCommand { get; set; }
        private bool sARS;
        private string sARSTaxNumber;

        public bool SARS
        { get => sARS; set => SetProperty(ref sARS,value); }

        public string SARSTaxNumber
        { get => sARSTaxNumber; set => SetProperty(ref sARSTaxNumber,value); }
    }
}

