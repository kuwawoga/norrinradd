﻿using System;
using MvvmHelpers;
using AfricanIDSPIMS.Services;
using System.Collections.Generic;
using Xamarin.Essentials;
using System.Threading.Tasks;
using AfricanIDSPIMS.Models;
using System.Net.Http;
using Newtonsoft.Json;

namespace AfricanIDSPIMS.ViewModels
{
	public class UsersViewModel : BaseViewModel
	{
        PersonalDetailsDataStore _User = new PersonalDetailsDataStore();
        IEnumerable<PersonalDetailsForm> usersList;

        public UsersViewModel()
		{
            _User = new PersonalDetailsDataStore();
            UsersList = new List<PersonalDetailsForm>();
            FetchAllUser();
        }

        public IEnumerable<PersonalDetailsForm> UsersList
        {
            get => usersList;
            set => SetProperty(ref usersList, value);
        }

        private async void FetchAllUser()
        {
            UsersList = await _User.GetItemsAsync();
        }
    }
}

