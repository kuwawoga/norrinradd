﻿using System;
using System.Collections.ObjectModel;
using MvvmHelpers;
using Xamarin.Essentials;

namespace AfricanIDSPIMS.ViewModels
{
	public class ProfileViewModel : BaseViewModel
	{
        string username;
        string email;
        string address;
        string mobileno;

        public ProfileViewModel()
        {
            if(App.CurrentUser == Enums.UserType.Admin)
            {
                Username = "Terrence Chipuka";
                Email = "kuwawoga@gmail.com";
                Address = "Avondale Hotel";
                MobileNo = "+27 83 944 8031";
            }

            else if(App.CurrentUser == Enums.UserType.User)
            {
                Username = Preferences.Get("FirstName", null);
                Email = Preferences.Get("Surname", null);
                Address = Preferences.Get("Email", null);
                MobileNo = Preferences.Get("MobileNo", null);

            }
        }

        public string Username
        {
            get => username;
            set => SetProperty(ref username, value);
        }

        public string Email
        {
            get => email;
            set => SetProperty(ref email, value);
        }

        public string Address
        {
            get => address;
            set => SetProperty(ref address, value);
        }

        public string MobileNo
        {
            get => mobileno;
            set => SetProperty(ref mobileno, value);
        }
    }
}

