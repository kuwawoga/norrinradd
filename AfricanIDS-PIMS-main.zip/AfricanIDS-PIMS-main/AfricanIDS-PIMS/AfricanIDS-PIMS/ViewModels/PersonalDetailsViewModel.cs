﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Windows.Input;
using MvvmHelpers;
using Xamarin.Forms;
using AfricanIDSPIMS.Models;
using Newtonsoft.Json;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using AfricanIDSPIMS.Services;

namespace AfricanIDSPIMS.ViewModels
{
	public class PersonalDetailsViewModel : BaseViewModel
	{
        PersonalDetailsDataStore personalDetails;
        public PersonalDetailsViewModel()
		{
            personalDetails = new PersonalDetailsDataStore();
            SaveCommand = new Command(SaveAction);
        }

        private async void SaveAction()
        {
            PersonalDetailsForm personalDetailsForm = new PersonalDetailsForm
            {
                FirstName = this.Name,
                Title = this.Title,
                Initials = this.Initials,
                MaidenName = this.MaidenName,
                Email = this.Email,
                MobileNo = this.MobileNo,
                Gender = this.Gender,
                NationalIDNumber = this.NationalIDNumber,
                DateofBirth = this.DateofBirth,
                Race = this.Race,
                Demographic = this.Demographic,
                MaritalStatus = this.MaritalStatus,
                Citizenship = this.Citizenship,
                CountryofResidence = this.CountryofResidence,
                Disability = this.Disability,
                NatureofDisability = this.NatureofDisability,
                VaccinatedforCovid = this.VaccinatedforCovid
            };


            var result = await personalDetails.AddItemAsync(personalDetailsForm);

            if(result)
            {
                await App.Current.MainPage.DisplayAlert("Success!", "Record added", "Ok");
            }

        }

        public ICommand SaveCommand { get; set; }
        private string title;
        private string initials;
        private string maidenName;
        private string name;
        private string email;
        private string mobile;
        private string gender;
        private string nationalIDNumber;
        private string dateofBirth;
        private string race;
        private string demographic;
        private string maritalStatus;
        private string citizenship;
        private string countryofResidence;
        private string disability;
        private string natureofDisability;
        private bool vaccinatedforCovid;

        public string Title
        { get => title; set => SetProperty(ref title,value); }

        public string Initials
        { get => initials; set => SetProperty(ref initials,value); }

        public string MaidenName
        { get => maidenName; set => SetProperty(ref maidenName,value); }


        public string Name
        { get => name; set => SetProperty(ref name, value); }

        public string Email
        { get => email; set => SetProperty(ref email, value); }

        public string MobileNo
        { get => mobile; set => SetProperty(ref mobile, value); }

        public string Gender
        { get => gender; set => SetProperty(ref gender,value); }

        public string NationalIDNumber
        { get => nationalIDNumber; set => SetProperty(ref nationalIDNumber,value); }

        public string DateofBirth
        { get => dateofBirth; set => SetProperty(ref dateofBirth,value); }

        public string Race
        { get => race; set => SetProperty(ref race,value); }

        public string Demographic
        { get => demographic; set => SetProperty(ref demographic,value); }

        public string MaritalStatus
        { get => maritalStatus; set => SetProperty(ref maritalStatus,value); }

        public string Citizenship
        { get => citizenship; set => SetProperty(ref citizenship,value); }

        public string CountryofResidence
        { get => countryofResidence; set => SetProperty(ref countryofResidence,value); }

        public string Disability
        { get => disability; set => SetProperty(ref disability,value); }

        public string NatureofDisability
        { get => natureofDisability; set => SetProperty(ref natureofDisability,value); }

        public bool VaccinatedforCovid
        { get => vaccinatedforCovid; set => SetProperty(ref vaccinatedforCovid,value); }
    }
}

