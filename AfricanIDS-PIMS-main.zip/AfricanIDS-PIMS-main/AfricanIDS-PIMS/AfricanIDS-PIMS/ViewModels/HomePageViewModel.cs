﻿using System;
using MvvmHelpers;
using AfricanIDSPIMS.Services;
using System.Collections.Generic;
using Xamarin.Essentials;
using System.Threading.Tasks;
using AfricanIDSPIMS.Models;
using System.Net.Http;
using Newtonsoft.Json;

namespace AfricanIDSPIMS.ViewModels
{
	public class HomePageViewModel : BaseViewModel
	{
        User user;
        public HomePageViewModel()
		{
        }
    }
}

