﻿using System;
using System.Windows.Input;
using AfricanIDSPIMS.Interfaces;
using MvvmHelpers;
using MvvmHelpers.Commands;
using AfricanIDSPIMS.Models;
using AfricanIDSPIMS.Enums;
using AfricanIDSPIMS.Views;
using AfricanIDSPIMS.Services;
using Xamarin.Essentials;

namespace AfricanIDSPIMS.ViewModels
{
	public class RegistrationViewModel : BaseViewModel
	{
		UserDataStore _user;
		AdminDataStore _admin;
		
		public RegistrationViewModel()
		{
			_user = new UserDataStore();
			_admin = new AdminDataStore();
			RegisterCommand = new Command(RegisterAction);
			LoginCommand = new Command(LoginAction);
		}

        private async void LoginAction()
        {
            await App.Current.MainPage.Navigation.PushAsync(new Views.RegistrationView());
        }

        private async void RegisterAction()
        {
            if(App.CurrentUser == UserType.Admin)
			{
				if(this.Email == App.AdminEmail && this.Password == App.AdminPass)
				{
                    await App.Current.MainPage.DisplayAlert("Message!", "You are admin please Login!", "Ok");
                    App.Current.MainPage = new LoginView();
                }
			}
			else if(App.CurrentUser == UserType.User)
			{
                User user = new User
                {
                    FirstName = this.FirstName,
                    Surname = this.SurName,
                    Email = this.Email,
                    MobileNo = this.MobileNo,
					Password = this.Password,
					ConfirmPassword = this.ConfirmPassword
                };

				Preferences.Set("FirstName", user.FirstName);
				Preferences.Set("Surname", user.Surname);
				Preferences.Set("Email", user.Email);
				Preferences.Set("Password", user.Password);
				Preferences.Set("MobileNo", user.MobileNo);

                var Result = await _user.AddItemAsync(user);
                if (Result)
                {
                    await App.Current.MainPage.DisplayAlert("Congrats!", "You have Successfully registered!", "Ok");
                    App.Current.MainPage = new LoginView();
                }
            }
        }

        public ICommand RegisterCommand { get; set; }
		public ICommand LoginCommand { get; set; }


        string firstname;
		string surname;
		string email;
		string mobileNo;
		string password;
		string confirmpassword;

		public string FirstName
		{
			get => firstname;
			set => SetProperty(ref firstname, value);
		}

		public string SurName
		{
			get => surname;
			set => SetProperty(ref surname, value);
		}

		public string Email
		{
			get => email;
			set => SetProperty(ref email, value);
		}

		public string Password
		{
			get => password;
			set => SetProperty(ref password, value);
		}

        public string ConfirmPassword
        {
            get => confirmpassword;
            set => SetProperty(ref confirmpassword, value);
        }

        public string MobileNo
		{
			get => mobileNo;
			set => SetProperty(ref mobileNo, value);
		}
		

		
	}
}

