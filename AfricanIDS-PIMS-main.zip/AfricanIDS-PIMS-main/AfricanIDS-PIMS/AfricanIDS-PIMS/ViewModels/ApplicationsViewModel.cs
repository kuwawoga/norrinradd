﻿using System;
using MvvmHelpers;

namespace AfricanIDSPIMS.ViewModels
{
	public class ApplicationsViewModel : BaseViewModel
	{
		public ApplicationsViewModel()
		{
		}
	}
}

