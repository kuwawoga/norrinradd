﻿using System;
using System.Windows.Input;
using MvvmHelpers;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace AfricanIDSPIMS.ViewModels
{
	public class DocumentsViewModel : BaseViewModel
	{
		public DocumentsViewModel()
		{
            SaveCommand = new Command(SaveAction);
        }

        private void SaveAction()
        {
            throw new NotImplementedException();
        }

        ICommand SaveCommand { get; set; }
        private string certifiedIDcopy;
        private string proofofResidence;
        private string updatedCV;
        private string taxReferenceNumber;
        private string qualifications;
        private string proofofBankdetails;

        public string CertifiedIDcopy
        { get => certifiedIDcopy; set=> SetProperty(ref certifiedIDcopy,value); }

        public string ProofofResidence
        { get => proofofResidence; set => SetProperty(ref proofofResidence,value); }

        public string UpdatedCV
        { get => updatedCV; set => SetProperty(ref updatedCV,value); }

        public string TaxReferenceNumber
        { get => taxReferenceNumber; set => SetProperty(ref taxReferenceNumber,value); }

        public string Qualifications
        { get => qualifications; set => SetProperty(ref qualifications,value); }

        public string ProofofBankdetails
        { get => proofofBankdetails; set => SetProperty(ref proofofBankdetails,value); }


    }
}

