﻿using System;
namespace AfricanIDSPIMS.ViewModels
{
	public class DashboardViewModel
	{
		public DashboardViewModel()
		{
		}
	}
}

