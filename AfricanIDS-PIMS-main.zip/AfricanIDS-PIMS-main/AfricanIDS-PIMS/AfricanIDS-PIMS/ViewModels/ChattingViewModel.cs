﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;
using MvvmHelpers;
using Xamarin.Forms;
using AfricanIDSPIMS.Models;

namespace AfricanIDSPIMS.ViewModels
{
	public class ChattingViewModel : BaseViewModel
	{
        public bool ShowScrollTap { get; set; } = false;
        public bool LastMessageVisible { get; set; } = true;
        public int PendingMessageCount { get; set; } = 0;
        public bool PendingMessageCountVisible { get { return PendingMessageCount > 0; } }

        public Queue<Message> DelayedMessages { get; set; } = new Queue<Message>();
        public ObservableCollection<Message> Messages { get; set; } = new ObservableCollection<Message>();
        public string TextToSend { get; set; }
        public ICommand OnSendCommand { get; set; }
        public ICommand MessageAppearingCommand { get; set; }
        public ICommand MessageDisappearingCommand { get; set; }

        public ChattingViewModel()
        {
            Messages.Insert(0, new Message() { Text = "Hi Tom, its Terrence from Admin , please upload your latest certified ID Copy" });
            Messages.Insert(0, new Message() { Text = " Hi Terrence ,is that the reason why my account is on hold?.", User = App.User });
            Messages.Insert(0, new Message() { Text = "Yes, if you can just upload that document our team will change the status of your account" });
            Messages.Insert(0, new Message() { Text = "Can i upload it in picture format?", User = App.User });
            Messages.Insert(0, new Message() { Text = "because thats what i have at the moment", User = App.User });
            Messages.Insert(0, new Message() { Text = "That should be fine right?", User = App.User });
            Messages.Insert(0, new Message() { Text = "Definetly our system allows you to upload pdf,png, jpg files?" });


            MessageAppearingCommand = new Command<Message>(OnMessageAppearing);
            MessageDisappearingCommand = new Command<Message>(OnMessageDisappearing);

            OnSendCommand = new Command(() =>
            {
                if (!string.IsNullOrEmpty(TextToSend))
                {
                    Messages.Insert(0, new Message() { Text = TextToSend, User = App.User });
                    TextToSend = string.Empty;
                }

            });
           
        }

        void OnMessageAppearing(Message message)
        {
            var idx = Messages.IndexOf(message);
            if (idx <= 6)
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    while (DelayedMessages.Count > 0)
                    {
                        Messages.Insert(0, DelayedMessages.Dequeue());
                    }
                    ShowScrollTap = false;
                    LastMessageVisible = true;
                    PendingMessageCount = 0;
                });
            }
        }

        void OnMessageDisappearing(Message message)
        {
            var idx = Messages.IndexOf(message);
            if (idx >= 6)
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    ShowScrollTap = true;
                    LastMessageVisible = false;
                });

            }
        }


        public event PropertyChangedEventHandler PropertyChanged;
    }
}

