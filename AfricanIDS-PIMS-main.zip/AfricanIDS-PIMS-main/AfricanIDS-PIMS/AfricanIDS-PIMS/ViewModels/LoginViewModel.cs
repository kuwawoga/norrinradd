﻿using System;
using System.Windows.Input;
using MvvmHelpers;
using AfricanIDSPIMS.Models;
using AfricanIDSPIMS.Enums;
using AfricanIDSPIMS.Services;
using AfricanIDSPIMS.Views;
using Xamarin.Forms;

namespace AfricanIDSPIMS.ViewModels
{
	public class LoginViewModel : BaseViewModel
	{
        UserDataStore _user;
        AdminDataStore _admin;

        public LoginViewModel()
		{
            _user = new UserDataStore();
            _admin = new AdminDataStore();
            LoginCommand = new Command(Login);
			RegisterCommand = new Command(Register);
		}

        private async void Register()
        {
			await App.Current.MainPage.Navigation.PushAsync(new Views.RegistrationView());
        }

        private async void Login()
        {
            //if (App.CurrentUser == UserType.Admin)
            //{
            //    if (App.CurrentUser == UserType.Admin)
            //    {
            //        if (this.Email == App.AdminEmail && this.Password == App.AdminPass)
            //        {
            //            await App.Current.MainPage.DisplayAlert("Congrats!", "You have Successfully Login!", "Ok");
            //            App.Current.MainPage = new AppShell();
            //        }
            //    }
            //}
            if (App.CurrentUser == UserType.User)
            {
                User user = new User
                {
                    Email = this.Email,
                    Password = this.Password
                };

                var Result = await _user.GetItemsAsync();

                foreach(var i in Result)
                {
                    if (i.Email == user.Email && i.Password == user.Password)
                    {
                        await App.Current.MainPage.DisplayAlert("Congrats!", "You have Successfully Login!", "Ok");
                        App.Current.MainPage = new AppShell();
                    }
                    break;
                }
            }
        }

        public ICommand LoginCommand { get; set; }
		public ICommand RegisterCommand { get; set; }

		string email;
		string password;


		public string Email
		{
			get => email;
			set => SetProperty(ref email, value);
		}

		public string Password
		{
			get => password;
			set => SetProperty(ref password, value);
		}
	}
}

