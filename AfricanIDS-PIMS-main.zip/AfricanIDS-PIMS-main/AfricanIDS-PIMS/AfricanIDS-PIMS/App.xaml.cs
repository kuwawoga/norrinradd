﻿using System;
using Xamarin.Forms;
using AfricanIDSPIMS.Views;
using Xamarin.Forms.Xaml;
using AfricanIDSPIMS.Interfaces;
using AfricanIDSPIMS.Services;
using AfricanIDSPIMS.Models;
using AfricanIDSPIMS.Enums;

namespace AfricanIDSPIMS
{
    public partial class App : Application
    {

        public static UserType CurrentUser;
        public static User SelectedUser;
        public static string AdminEmail = "admin";
        public static string AdminPass = "121Pass";

        public static string User = "admin";

        public App ()
        {
            InitializeComponent();
            MainPage = new NavigationPage(new OnboardingView());
        }

        protected override void OnStart ()
        {
        }

        protected override void OnSleep ()
        {
        }

        protected override void OnResume ()
        {
        }
    }
}

