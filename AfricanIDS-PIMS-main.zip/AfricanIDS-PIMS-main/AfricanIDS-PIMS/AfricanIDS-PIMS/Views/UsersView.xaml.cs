﻿using System;
using System.Collections.Generic;
using AfricanIDSPIMS.ViewModels;
using AfricanIDSPIMS.Models;
using Xamarin.Forms;
using System.Linq;

namespace AfricanIDSPIMS.Views
{
    public partial class UsersView : ContentPage
    {
        public UsersView()
        {
            InitializeComponent();
            BindingContext = new UsersViewModel();
        }

        async void CollectionView_SelectionChanged(System.Object sender, Xamarin.Forms.SelectionChangedEventArgs e)
        {
            App.SelectedUser = (e.CurrentSelection.FirstOrDefault())as User;
            await Navigation.PushAsync(new DashboardView());
            //ListofUsers.SelectedItem = null;
        }

        async void AddNewUser_Click(System.Object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new DashboardView());
        }
    }
}

