﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace AfricanIDSPIMS.Views
{	
	public partial class SettingsView : ContentPage
	{	
		public SettingsView ()
		{
			InitializeComponent ();
		}
	}
}

