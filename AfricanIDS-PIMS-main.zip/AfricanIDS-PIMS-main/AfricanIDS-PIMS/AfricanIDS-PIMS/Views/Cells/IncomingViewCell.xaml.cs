﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace AfricanIDSPIMS.Views.Cells
{	
	public partial class IncomingViewCell : ViewCell
	{	
		public IncomingViewCell ()
		{
			InitializeComponent ();
		}
	}
}

