﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace AfricanIDSPIMS.Views.Cells
{	
	public partial class OutgoingViewCell : ViewCell
	{	
		public OutgoingViewCell ()
		{
			InitializeComponent ();
		}
	}
}

