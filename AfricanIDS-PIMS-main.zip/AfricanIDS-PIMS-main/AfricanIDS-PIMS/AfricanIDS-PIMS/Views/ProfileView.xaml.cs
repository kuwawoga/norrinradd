﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using AfricanIDSPIMS.ViewModels;

namespace AfricanIDSPIMS.Views
{	
	public partial class ProfileView : ContentPage
	{	
		public ProfileView ()
		{
			InitializeComponent ();
            BindingContext = new ProfileViewModel();
        }

        
    }
}

