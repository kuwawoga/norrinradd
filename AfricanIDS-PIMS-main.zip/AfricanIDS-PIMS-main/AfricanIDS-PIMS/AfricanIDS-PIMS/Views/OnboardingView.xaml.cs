﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace AfricanIDSPIMS.Views
{
    public partial class OnboardingView : ContentPage
    {
        public OnboardingView()
        {
            InitializeComponent();
        }

        void Admin(System.Object sender, System.EventArgs e)
        {
            App.CurrentUser = Enums.UserType.Admin;
            App.Current.MainPage = new AppShell();
        }

        void User(System.Object sender, System.EventArgs e)
        {
            App.CurrentUser = Enums.UserType.User;
            App.Current.MainPage = new NavigationPage(new LoginView());
        }

    }
}

