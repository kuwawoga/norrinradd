﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace AfricanIDSPIMS.Views
{
    public partial class DashboardView : ContentPage
    {
        public DashboardView()
        {
            InitializeComponent();
            BindingContext = new ViewModels.DashboardViewModel();
        }

        async void Profile_Click(System.Object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new ProfileView());
        }

        async void Bank_Click(System.Object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new BankDetailsView());
        }

        async void Personal_click(System.Object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new PersonalDetails());
        }

        async void Tax_Click(System.Object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new TaxView());
        }

        async void Doc_Click(System.Object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new DocumentsView());
        }

        async void Chat_Click(System.Object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new ChattingView());
        }
    }
}

