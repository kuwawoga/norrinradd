﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace AfricanIDSPIMS.Views
{
    public partial class TaxView : ContentPage
    {
        public TaxView()
        {
            InitializeComponent();
        }
    }
}

