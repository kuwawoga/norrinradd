﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using Xamarin.Essentials;

namespace AfricanIDSPIMS.Views
{
    public partial class DocumentsView : ContentPage
    {
        public DocumentsView()
        {
            InitializeComponent();
        }

        async void ID_Click(System.Object sender, System.EventArgs e)
        {
            var result = await FilePicker.PickAsync(new PickOptions
            {
                PickerTitle = "File",
                FileTypes = FilePickerFileType.Jpeg
            });
        }

        async void Residence_Click(System.Object sender, System.EventArgs e)
        {
            var result = await FilePicker.PickAsync(new PickOptions
            {
                PickerTitle = "File",
                FileTypes = FilePickerFileType.Jpeg
            });
        }

        async void CV_Click(System.Object sender, System.EventArgs e)
        {
            var result = await FilePicker.PickAsync(new PickOptions
            {
                PickerTitle = "File",
                FileTypes = FilePickerFileType.Jpeg
            });
        }

        async void Reference_Click(System.Object sender, System.EventArgs e)
        {
            var result = await FilePicker.PickAsync(new PickOptions
            {
                PickerTitle = "File",
                FileTypes = FilePickerFileType.Jpeg
            });
        }

        async void Qualifications_Click(System.Object sender, System.EventArgs e)
        {
            var result = await FilePicker.PickAsync(new PickOptions
            {
                PickerTitle = "File",
                FileTypes = FilePickerFileType.Jpeg
            });
        }

        async void Bankdetails_Click(System.Object sender, System.EventArgs e)
        {
            var result = await FilePicker.PickAsync(new PickOptions
            {
                PickerTitle = "File",
                FileTypes = FilePickerFileType.Jpeg
            });
        }
    }
}

