﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace AfricanIDSPIMS.Views
{
    public partial class RegistrationView : ContentPage
    {
        public RegistrationView()
        {
            InitializeComponent();
            BindingContext = new ViewModels.RegistrationViewModel();
        }
    }
}

