﻿using System;
using System.Collections.Generic;
using AfricanIDSPIMS.ViewModels;
using Xamarin.Forms;

namespace AfricanIDSPIMS.Views
{
    public partial class PersonalDetails : ContentPage
    {
        public PersonalDetails()
        {
            InitializeComponent();
            BindingContext = new PersonalDetailsViewModel();
        }
    }
}

