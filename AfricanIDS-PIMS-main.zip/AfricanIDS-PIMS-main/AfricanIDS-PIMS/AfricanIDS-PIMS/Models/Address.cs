﻿using System;
namespace AfricanIDSPIMS.Models
{
	public class Address
	{
        public int Id { get; set; }
        public string PhysicalAddress { get; set; }
        public string PostalAddress { get; set; }
    }
}

