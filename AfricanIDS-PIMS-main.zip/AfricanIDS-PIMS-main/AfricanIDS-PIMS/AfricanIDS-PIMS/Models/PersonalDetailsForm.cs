﻿using System;
namespace AfricanIDSPIMS.Models
{
	public class PersonalDetailsForm
	{
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string MobileNo { get; set; }
        public int OTP { get; set; }
        public string Title { get; set; }
        public string Initials { get; set; }
        public string MaidenName { get; set; }
        public string Gender { get; set; }
        public string NationalIDNumber { get; set; }
        public string DateofBirth { get; set; }
        public string Race { get; set; }
        public string Demographic { get; set; }
        public string MaritalStatus { get; set; }
        public string Citizenship { get; set; }
        public string CountryofResidence { get; set; }
        public string Disability { get; set; }
        public string NatureofDisability { get; set; }
        public bool VaccinatedforCovid { get; set; }
    }
}

