﻿using System;
namespace AfricanIDSPIMS.Models
{
	public class Documents
	{
        public int Id { get; set; }
        public string CertifiedIDcopy { get; set; }
        public string ProofofResidence { get; set; }
        public string UpdatedCV { get; set; }
        public string TaxReferenceNumber { get; set; }
        public string Qualifications { get; set; }
        public string ProofofBankdetails { get; set; }
    }
}

