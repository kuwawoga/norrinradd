﻿using System;
namespace AfricanIDSPIMS.Models
{
	public class User
	{
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string MobileNo { get; set; }
        public int OTP { get; set; }

        //More Details
        public PersonalDetailsForm PersonalDetailsForm { get; set; }
        public TaxNumber TaxNumber { get; set; }
        public Address Address { get; set; }
        public BankDetails BankDetails { get; set; }
        public Documents Documents { get; set; }
    }
}

