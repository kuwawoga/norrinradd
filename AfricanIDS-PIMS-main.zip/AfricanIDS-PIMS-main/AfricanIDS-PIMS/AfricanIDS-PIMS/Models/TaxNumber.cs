﻿using System;
namespace AfricanIDSPIMS.Models
{
	public class TaxNumber
	{
        public int Id { get; set; }
        public bool SARS { get; set; }
        public string SARSTaxNumber { get; set; }
    }
}

