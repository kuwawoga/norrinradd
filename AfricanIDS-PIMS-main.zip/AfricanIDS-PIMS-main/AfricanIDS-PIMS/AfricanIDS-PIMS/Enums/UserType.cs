﻿using System;
namespace AfricanIDSPIMS.Enums
{
	public enum UserType
	{
		Admin,
		User
	}
}

